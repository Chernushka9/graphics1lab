﻿namespace VLab4Paralel
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.startAll = new System.Windows.Forms.Button();
            this.resume1 = new System.Windows.Forms.Button();
            this.pause1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(290, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(799, 443);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // startAll
            // 
            this.startAll.Location = new System.Drawing.Point(603, 518);
            this.startAll.Name = "startAll";
            this.startAll.Size = new System.Drawing.Size(150, 42);
            this.startAll.TabIndex = 4;
            this.startAll.Text = "START THREADS";
            this.startAll.UseVisualStyleBackColor = true;
            this.startAll.Click += new System.EventHandler(this.startAll_Click);
            // 
            // resume1
            // 
            this.resume1.Location = new System.Drawing.Point(529, 484);
            this.resume1.Name = "resume1";
            this.resume1.Size = new System.Drawing.Size(75, 23);
            this.resume1.TabIndex = 5;
            this.resume1.Text = "Resume1";
            this.resume1.UseVisualStyleBackColor = true;
            this.resume1.Click += new System.EventHandler(this.resume1_Click);
            // 
            // pause1
            // 
            this.pause1.Location = new System.Drawing.Point(750, 484);
            this.pause1.Name = "pause1";
            this.pause1.Size = new System.Drawing.Size(75, 23);
            this.pause1.TabIndex = 6;
            this.pause1.Text = "Pause1";
            this.pause1.UseVisualStyleBackColor = true;
            this.pause1.Click += new System.EventHandler(this.pause1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1352, 572);
            this.Controls.Add(this.pause1);
            this.Controls.Add(this.resume1);
            this.Controls.Add(this.startAll);
            this.Controls.Add(this.pictureBox3);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.HelpButton = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Gray;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button startAll;
        private System.Windows.Forms.Button resume1;
        private System.Windows.Forms.Button pause1;
    }
}

