﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace VLab4Paralel
{
    public partial class Form1 : Form
    {
        Thread thread;
        Graphics graphics;
        Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        Color GetRandomColor()
        {
            return Color.FromArgb((byte)random.Next(0, 255), (byte)random.Next(0, 255), (byte)random.Next(0, 255));
        }

        void DrawElipse1(Color color, int xr, int yr, int x, int y)
        {
            Pen pen = new Pen(color);
            graphics.DrawEllipse(pen, xr, yr, x, y);
        }

        void DrawSquareAnimation()
        {
            graphics = pictureBox3.CreateGraphics();
            SolidBrush fon = new SolidBrush(Color.Black);
            while (true)
            {
                graphics.FillRectangle(fon, 0, 0, pictureBox3.Width, pictureBox3.Height);
                for (int i = 30; i < 800; i +=15)
                {

                    DrawElipse1(GetRandomColor(), (pictureBox3.Width / 2) - i / 2 , (pictureBox3.Height / 2) - i / 2, i, i);
                    Thread.Sleep(100);
                }
            }
        }

        private void startAll_Click(object sender, EventArgs e)
        {
            thread = new Thread(DrawSquareAnimation);
            thread.Start();
        }

        private void resume1_Click(object sender, EventArgs e)
        {
            thread.Resume();
        }

        private void pause1_Click(object sender, EventArgs e)
        {
            thread.Suspend();
        }
    }
}
